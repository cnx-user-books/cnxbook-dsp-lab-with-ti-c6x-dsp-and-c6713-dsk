/*****************************************************************************
This program is a modification of TI's example for the 6713 DSK.
Much of that program is not used in this project except the 
set-up of a few objects. In the example the objects are set up
different from what is done here and they were set up manually. In
this code all the objects are defined in the TCF file.

From the TI program (with modifications):
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
This example demonstrates the use of IOM drivers with SIOs and tasks by 
using the DIO class driver with a user defined device mini-driver 
called "codec" and a class driver DIO instance called "dio_codec". This is 
the loopback application where audio is read from an input SIO, then sent 
back via an output SIO.
The following objects need to be created in the DSP/BIOS
configuration for this application:
 * A UDEV object, which links in a user device driver. In this
  case the UDEV is a codec based IOM device driver: udevCodec.
 * A DIO object, which links the UDEV object. dioCodec.
 * Two streams, inStream and outStream.
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

This project uses two libraries from the DSK example:
c6x1x_edma_mcbsp.l67 and dsk6713_edma_aic23.l67
The functions and data structures are described (somewhat) in the following
documents:
SPRA677 A DSP/BIOS AIC23 Codec Device Driver for the TMS320C6713 DSK
SPRA846A A DSP/BIOS EDMA McBSP Device Driver for TMS320C6x1x DSPs

Parameters for the udevCodec user-defined device driver:
init function: _DSK6713_EDMA_AIC23_init
function table ptr: _DSK6713_EDMA_AIC23_FXNS
device params ptr: _AIC23CodecConfig

******************************************************************************/

// Author: David Waldo
// Date: 7/15/09

#include <std.h>
#include <csl.h>
#include <log.h>
#include <sys.h>
#include <sio.h>
#include "DSK6713_audiocfg.h"
#include "aic23.h"

/*****************************************************************************
Structures and macros for setting up the CODEC
Some of these structures and macros were derived from those in the
header file aic23.h.
******************************************************************************/

/*****************************************************************************
Structure DSK6713_EDMA_AIC23_DevParams
This structure is described in the document SPRA677
******************************************************************************/
typedef struct DSK6713_EDMA_AIC23_DevParams {
Int versionId;
Int cacheCalls;
Int irqId;
AIC23_Params aic23;
Uns intrMask;
Int edmaPriority;
} DSK6713_EDMA_AIC23_DevParams;

/* This macro is used to set up the CODEC using the Mic input */
#define AIC23_REG4_MIC                                            \
AIC23_9BITWORD(         /* REG 4: analog audio path control */    \
0,                  /* reserved */                                \
0,0,                /* sidetone attenuation: 6 dB */              \
0,                  /* sidetone: disabled */                      \
1,                  /* DAC: selected */                           \
0,                  /* bypass: off */                             \
1,                  /* input select for ADC: mic */               \
0,                  /* microphone mute: disabled */               \
1                   /* microphone boost: enabled */               \
)

/* This macro is used to set up the CODEC using the Line input */
/* Full scale input on the line-in is about 6.0V peak to peak */
#define AIC23_REG4_LINE                                           \
AIC23_9BITWORD(         /* REG 4: analog audio path control */    \
0,                  /* reserved */                                \
0,0,                /* sidetone attenuation: 6 dB */              \
0,                  /* sidetone: disabled */                      \
1,                  /* DAC: selected */                           \
0,                  /* bypass: off */                             \
0,                  /* input select for ADC: line */              \
0,                  /* microphone mute: disabled */               \
1                   /* microphone boost: enabled 20dB */          \
)

/* Sample rate can be set with
AIC23_REG8_8KHZ
AIC23_REG8_32KHZ
AIC23_REG8_44_1KHZ
AIC23_REG8_48KHZ
AIC23_REG8_96KHZ
*/

/*****************************************************************************
Structure AIC23CodecConfig
In the configuration tool set the udevCodec driver device params ptr to
_AIC23CodecConfig. This structure will be used to set up the CODEC.
The data manual for the TLV320AIC23 Codec is SLWS106. In it the definitions
of the registers can be found. The header file aic23.h contains some useful
definitions.
******************************************************************************/
DSK6713_EDMA_AIC23_DevParams AIC23CodecConfig ={
0x0000AB01,	//VersionId
0x00000001, //cacheCalls
0x00000008, //irqId
AIC23_REG0_DEFAULT,
AIC23_REG1_DEFAULT,
AIC23_REG2_DEFAULT,
AIC23_REG3_DEFAULT,
AIC23_REG4_MIC,	// Use the macro for Mic or Line here
AIC23_REG5_DEFAULT,
AIC23_REG6_DEFAULT,
AIC23_REG7_DEFAULT,
AIC23_REG8_48KHZ,	// Set the sample rate here
AIC23_REG9_DEFAULT,
0x00000001, //intrMask
0x00000001  //edmaPriority
};


// In the C67x an MADU is an 8-bit byte.

// Buffers placed in external memory are aligned on a 128 bytes boundary.
// In addition, the buffer should be of a size multiple of 128 bytes for 
// the cache to work optimally on the C6x.
// This means that if the SIO streams are placed in SDRAM
// then the size of the buffers must be a multiple of 128 bytes and the
// alignment should be set to 128.
// If the SIO streams are placed in IRAM
// then the size of the buffers can be anything and the
// alignment can be anything.

// These are the definitions for the inStream and outStream SIO streams

#define CHANLEN 256		// Number of samples per channel
#define BUFLEN CHANLEN*2    // Number of samples in the frame
#define BUFSIZE BUFLEN*2 	// Size of a buffer in MADUs, This needs to be set in
							// the inStream and outStream definition as the size
							// of the buffers


/*****************************************************************************
 main
******************************************************************************/
Void main()
{
    LOG_printf(&trace, "tsk_audio started");
}

/*****************************************************************************
 processing
 This function copies from the input SIO to the output SIO. You could
 easily replace the copy function with a signal processing algorithm. 
******************************************************************************/

Void processing()
{
    Int i;
    Int nmadus;         /* number of minimal addressable units */
    Int16 *inbuf, *outbuf;

	// Get an empty buffer to swap when SIO_get is called
	if ((nmadus = SIO_staticbuf(&inStream, (Ptr *)&inbuf)) < 0) {
		SYS_abort("Error getting buffer from input stream");
	}
	// Get an empty buffer to fill before calling SIO_put
	nmadus = SIO_staticbuf(&outStream, (Ptr *)&outbuf);
	if ((nmadus = SIO_staticbuf(&outStream, (Ptr *)&outbuf)) < 0) {
		SYS_abort("Error getting buffer from output stream");
	}

    // Loop forever
    while(1) {
        /*Get a full buffer from the input stream */
        if ((nmadus = SIO_get(&inStream, (Ptr *)&inbuf)) < 0) {
            SYS_abort("Error getting buffer from input stream");
        }

		// Even numbered elements are the left channel (Silver on splitter)
		// and odd elements are the right channel (Gold on splitter).
        // This simply moves each channel from the input to the output.
		// To perform signal processing, replace this code
        for (i = 0; i < CHANLEN; i++) {
            outbuf[2*i] = inbuf[2*i];	// Left channel (Silver on splitter)
			outbuf[2*i+1] = inbuf[2*i+1];	// Right channel (Gold on splitter)
        }

        /* Put full buffer in the output stream */
        if (nmadus = SIO_put(&outStream, (Ptr *)&outbuf, nmadus) < 0 ) {
            SYS_abort("Error getting buffer from output stream");
        }

    } // end of while
} // end of function processing




